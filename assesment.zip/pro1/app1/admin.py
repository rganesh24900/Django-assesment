from django.contrib import admin
from .models import advisor


admin.site.register(advisor)



# Register your models here.
